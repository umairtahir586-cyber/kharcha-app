export type Category = {
  id: string
  user_id: string
  name: string
  icon: string
  color: string
  created_at: string
}

export type Expense = {
  id: string
  user_id: string
  amount: number
  description: string | null
  category_id: string | null
  payment_method: 'cash' | 'card' | 'online' | 'bank_transfer'
  expense_date: string
  screenshot_url: string | null
  is_recurring: boolean
  recurring_frequency: 'daily' | 'weekly' | 'monthly' | 'yearly' | null
  created_at: string
  updated_at: string
  category?: Category | null
}

export type Budget = {
  id: string
  user_id: string
  category_id: string
  amount: number
  period: 'weekly' | 'monthly' | 'yearly'
  start_date: string
  created_at: string
  category?: Category
}

export type Profile = {
  id: string
  full_name: string | null
  monthly_salary: number
  currency: string
  created_at: string
  updated_at: string
}

export type ExpenseWithCategory = Expense & {
  category: Category | null
}

export type DailySummary = {
  date: string
  total: number
  count: number
  expenses: ExpenseWithCategory[]
}

export type CategorySummary = {
  category: Category | null
  total: number
  count: number
  percentage: number
}

export type PaymentMethodSummary = {
  method: string
  total: number
  count: number
  percentage: number
}
