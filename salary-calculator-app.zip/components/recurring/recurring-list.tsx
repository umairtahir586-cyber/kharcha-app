'use client'

import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { formatPKR, formatDate, getPaymentMethodLabel } from '@/lib/format'
import { Plus, Repeat, Calendar } from 'lucide-react'
import type { ExpenseWithCategory } from '@/lib/types'

interface RecurringListProps {
  expenses: ExpenseWithCategory[]
}

const frequencyLabels: Record<string, string> = {
  daily: 'Daily',
  weekly: 'Weekly',
  monthly: 'Monthly',
  yearly: 'Yearly',
}

export function RecurringList({ expenses }: RecurringListProps) {
  // Group by frequency
  const byFrequency = expenses.reduce<Record<string, ExpenseWithCategory[]>>((acc, expense) => {
    const freq = expense.recurring_frequency ?? 'monthly'
    if (!acc[freq]) {
      acc[freq] = []
    }
    acc[freq].push(expense)
    return acc
  }, {})

  if (expenses.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Repeat className="h-12 w-12 text-muted-foreground mb-4" />
          <p className="text-muted-foreground text-center mb-4">
            No recurring expenses set up yet
          </p>
          <Button asChild>
            <Link href="/dashboard/expenses/new">
              <Plus className="mr-2 h-4 w-4" />
              Add Recurring Expense
            </Link>
          </Button>
        </CardContent>
      </Card>
    )
  }

  // Calculate monthly total
  const monthlyTotal = expenses.reduce((sum, e) => {
    const amount = Number(e.amount)
    switch (e.recurring_frequency) {
      case 'daily': return sum + amount * 30
      case 'weekly': return sum + amount * 4
      case 'monthly': return sum + amount
      case 'yearly': return sum + amount / 12
      default: return sum + amount
    }
  }, 0)

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Estimated Monthly</p>
              <p className="text-2xl font-bold">{formatPKR(monthlyTotal)}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Total Recurring</p>
              <p className="text-lg font-semibold">{expenses.length} expenses</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {Object.entries(byFrequency).map(([frequency, freqExpenses]) => (
        <div key={frequency} className="space-y-3">
          <h3 className="font-semibold flex items-center gap-2">
            <Repeat className="h-4 w-4" />
            {frequencyLabels[frequency] ?? frequency}
            <span className="text-muted-foreground font-normal">
              ({freqExpenses.length})
            </span>
          </h3>
          <Card>
            <CardContent className="p-0 divide-y">
              {freqExpenses.map((expense) => (
                <div
                  key={expense.id}
                  className="flex items-center justify-between p-4"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="h-10 w-10 rounded-full flex items-center justify-center"
                      style={{
                        backgroundColor: expense.category?.color
                          ? `${expense.category.color}20`
                          : '#f3f4f6',
                      }}
                    >
                      <Calendar
                        className="h-5 w-5"
                        style={{ color: expense.category?.color ?? '#6b7280' }}
                      />
                    </div>
                    <div>
                      <p className="font-medium">
                        {expense.description ?? expense.category?.name ?? 'Expense'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {expense.category?.name ?? 'Uncategorized'} • {getPaymentMethodLabel(expense.payment_method)}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{formatPKR(Number(expense.amount))}</p>
                    <p className="text-xs text-muted-foreground">
                      Started {formatDate(expense.expense_date)}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      ))}

      <div className="flex justify-center">
        <Button variant="outline" asChild>
          <Link href="/dashboard/expenses/new">
            <Plus className="mr-2 h-4 w-4" />
            Add Recurring Expense
          </Link>
        </Button>
      </div>
    </div>
  )
}
