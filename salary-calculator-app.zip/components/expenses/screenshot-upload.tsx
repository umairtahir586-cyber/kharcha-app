'use client'

import { useState, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Upload, X, Loader2, Sparkles, Image as ImageIcon } from 'lucide-react'
import Image from 'next/image'

interface ScreenshotUploadProps {
  onUpload: (url: string) => void
  onExtract: (data: {
    amount?: number
    description?: string
    date?: string
    merchant?: string
  }) => void
  currentUrl?: string
}

export function ScreenshotUpload({ onUpload, onExtract, currentUrl }: ScreenshotUploadProps) {
  const [isUploading, setIsUploading] = useState(false)
  const [isExtracting, setIsExtracting] = useState(false)
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentUrl ?? null)
  const [error, setError] = useState<string | null>(null)

  const handleFileChange = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file')
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('File size must be less than 5MB')
      return
    }

    setError(null)
    setIsUploading(true)

    try {
      // Create preview
      const preview = URL.createObjectURL(file)
      setPreviewUrl(preview)

      // Upload to Vercel Blob
      const formData = new FormData()
      formData.append('file', file)

      const uploadRes = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      })

      if (!uploadRes.ok) {
        throw new Error('Failed to upload file')
      }

      const { url } = await uploadRes.json()
      onUpload(url)
      setPreviewUrl(url)

      // Auto-extract with AI
      setIsUploading(false)
      setIsExtracting(true)

      const extractRes = await fetch('/api/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageUrl: url }),
      })

      if (extractRes.ok) {
        const data = await extractRes.json()
        onExtract(data)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed')
      setPreviewUrl(null)
    } finally {
      setIsUploading(false)
      setIsExtracting(false)
    }
  }, [onUpload, onExtract])

  const handleRemove = () => {
    setPreviewUrl(null)
    onUpload('')
  }

  const handleManualExtract = async () => {
    if (!previewUrl) return
    
    setIsExtracting(true)
    try {
      const res = await fetch('/api/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageUrl: previewUrl }),
      })

      if (res.ok) {
        const data = await res.json()
        onExtract(data)
      }
    } catch (err) {
      setError('Failed to extract data')
    } finally {
      setIsExtracting(false)
    }
  }

  if (previewUrl) {
    return (
      <div className="space-y-4">
        <div className="relative aspect-video w-full max-w-sm overflow-hidden rounded-lg border bg-muted">
          <Image
            src={previewUrl}
            alt="Receipt screenshot"
            fill
            className="object-contain"
          />
          <Button
            type="button"
            variant="destructive"
            size="icon"
            className="absolute right-2 top-2 h-8 w-8"
            onClick={handleRemove}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <Button
          type="button"
          variant="outline"
          onClick={handleManualExtract}
          disabled={isExtracting}
          className="w-full"
        >
          {isExtracting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Extracting details...
            </>
          ) : (
            <>
              <Sparkles className="mr-2 h-4 w-4" />
              Re-extract with AI
            </>
          )}
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <label
        htmlFor="screenshot"
        className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-8 cursor-pointer hover:bg-muted/50 transition-colors"
      >
        {isUploading ? (
          <>
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            <p className="mt-2 text-sm text-muted-foreground">Uploading...</p>
          </>
        ) : (
          <>
            <div className="flex items-center justify-center rounded-full bg-primary/10 p-3">
              <Upload className="h-6 w-6 text-primary" />
            </div>
            <p className="mt-3 text-sm font-medium">
              Upload payment screenshot
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              AI will automatically extract expense details
            </p>
          </>
        )}
        <Input
          id="screenshot"
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
          disabled={isUploading}
        />
      </label>

      {error && (
        <p className="text-sm text-destructive">{error}</p>
      )}

      {isExtracting && (
        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <Sparkles className="h-4 w-4 animate-pulse text-primary" />
          <span>AI is analyzing the screenshot...</span>
        </div>
      )}
    </div>
  )
}
