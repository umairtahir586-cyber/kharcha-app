'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { formatPKR, formatDate, getPaymentMethodLabel, getRelativeDate } from '@/lib/format'
import { Banknote, CreditCard, Smartphone, Building, Trash2, Edit, Image } from 'lucide-react'
import type { ExpenseWithCategory, Category } from '@/lib/types'

interface ExpenseListProps {
  expenses: ExpenseWithCategory[]
  categories: Category[]
}

const paymentIcons = {
  cash: Banknote,
  card: CreditCard,
  online: Smartphone,
  bank_transfer: Building,
}

export function ExpenseList({ expenses, categories }: ExpenseListProps) {
  const router = useRouter()
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  const handleDelete = async () => {
    if (!deleteId) return
    setIsDeleting(true)

    const supabase = createClient()
    await supabase.from('expenses').delete().eq('id', deleteId)

    setDeleteId(null)
    setIsDeleting(false)
    router.refresh()
  }

  // Group expenses by date
  const groupedExpenses = expenses.reduce<Record<string, ExpenseWithCategory[]>>((acc, expense) => {
    const date = expense.expense_date
    if (!acc[date]) {
      acc[date] = []
    }
    acc[date].push(expense)
    return acc
  }, {})

  const sortedDates = Object.keys(groupedExpenses).sort(
    (a, b) => new Date(b).getTime() - new Date(a).getTime()
  )

  if (expenses.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <p className="text-muted-foreground text-center">
            No expenses found. Start tracking your spending!
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <div className="space-y-6">
        {sortedDates.map((date) => {
          const dayExpenses = groupedExpenses[date]
          const dayTotal = dayExpenses.reduce((sum, e) => sum + Number(e.amount), 0)

          return (
            <div key={date} className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold">{getRelativeDate(date)}</h3>
                  <span className="text-sm text-muted-foreground">
                    {formatDate(date)}
                  </span>
                </div>
                <span className="text-sm font-semibold text-destructive">
                  -{formatPKR(dayTotal)}
                </span>
              </div>

              <Card>
                <CardContent className="p-0 divide-y">
                  {dayExpenses.map((expense) => {
                    const PaymentIcon = paymentIcons[expense.payment_method] ?? Banknote
                    return (
                      <div
                        key={expense.id}
                        className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className="flex h-10 w-10 items-center justify-center rounded-full"
                            style={{
                              backgroundColor: expense.category?.color
                                ? `${expense.category.color}20`
                                : '#f3f4f6',
                            }}
                          >
                            <PaymentIcon
                              className="h-5 w-5"
                              style={{ color: expense.category?.color ?? '#6b7280' }}
                            />
                          </div>
                          <div>
                            <p className="font-medium text-sm">
                              {expense.description ?? expense.category?.name ?? 'Expense'}
                            </p>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <span>{expense.category?.name ?? 'Uncategorized'}</span>
                              <span>•</span>
                              <span>{getPaymentMethodLabel(expense.payment_method)}</span>
                              {expense.screenshot_url && (
                                <>
                                  <span>•</span>
                                  <Image className="h-3 w-3" />
                                </>
                              )}
                              {expense.is_recurring && (
                                <>
                                  <span>•</span>
                                  <span className="text-primary">Recurring</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">
                            -{formatPKR(Number(expense.amount))}
                          </span>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => router.push(`/dashboard/expenses/${expense.id}/edit`)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive hover:text-destructive"
                              onClick={() => setDeleteId(expense.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </CardContent>
              </Card>
            </div>
          )
        })}
      </div>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Expense</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this expense? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={isDeleting}
            >
              {isDeleting ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
