'use client'

import { useRouter, useSearchParams, usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { PAYMENT_METHODS } from '@/lib/format'
import { X } from 'lucide-react'
import type { Category } from '@/lib/types'

interface ExpenseFiltersProps {
  categories: Category[]
}

export function ExpenseFilters({ categories }: ExpenseFiltersProps) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const updateFilter = (key: string, value: string | null) => {
    const params = new URLSearchParams(searchParams.toString())
    if (value) {
      params.set(key, value)
    } else {
      params.delete(key)
    }
    router.push(`${pathname}?${params.toString()}`)
  }

  const clearFilters = () => {
    router.push(pathname)
  }

  const hasFilters = searchParams.has('category') || 
                     searchParams.has('payment') || 
                     searchParams.has('start') || 
                     searchParams.has('end')

  return (
    <div className="rounded-lg border bg-card p-4">
      <div className="flex flex-wrap items-end gap-4">
        <div className="space-y-2 min-w-[180px]">
          <Label>Category</Label>
          <Select
            value={searchParams.get('category') ?? ''}
            onValueChange={(value) => updateFilter('category', value || null)}
          >
            <SelectTrigger>
              <SelectValue placeholder="All categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All categories</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat.id} value={cat.id}>
                  {cat.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2 min-w-[180px]">
          <Label>Payment Method</Label>
          <Select
            value={searchParams.get('payment') ?? ''}
            onValueChange={(value) => updateFilter('payment', value || null)}
          >
            <SelectTrigger>
              <SelectValue placeholder="All methods" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All methods</SelectItem>
              {PAYMENT_METHODS.map((method) => (
                <SelectItem key={method.value} value={method.value}>
                  {method.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>From</Label>
          <Input
            type="date"
            value={searchParams.get('start') ?? ''}
            onChange={(e) => updateFilter('start', e.target.value || null)}
            className="w-[160px]"
          />
        </div>

        <div className="space-y-2">
          <Label>To</Label>
          <Input
            type="date"
            value={searchParams.get('end') ?? ''}
            onChange={(e) => updateFilter('end', e.target.value || null)}
            className="w-[160px]"
          />
        </div>

        {hasFilters && (
          <Button variant="ghost" size="sm" onClick={clearFilters}>
            <X className="mr-2 h-4 w-4" />
            Clear
          </Button>
        )}
      </div>
    </div>
  )
}
