'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { PAYMENT_METHODS, RECURRING_FREQUENCIES, toISODateString } from '@/lib/format'
import { Loader2, AlertCircle } from 'lucide-react'
import { ScreenshotUpload } from './screenshot-upload'
import type { Category, Expense } from '@/lib/types'

interface ExpenseFormProps {
  categories: Category[]
  userId: string
  expense?: Expense
}

export function ExpenseForm({ categories, userId, expense }: ExpenseFormProps) {
  const router = useRouter()
  const isEditing = !!expense

  const [amount, setAmount] = useState(expense?.amount?.toString() ?? '')
  const [description, setDescription] = useState(expense?.description ?? '')
  const [categoryId, setCategoryId] = useState(expense?.category_id ?? '')
  const [paymentMethod, setPaymentMethod] = useState<string>(
    expense?.payment_method ?? 'cash'
  )
  const [expenseDate, setExpenseDate] = useState(
    expense?.expense_date ?? toISODateString(new Date())
  )
  const [isRecurring, setIsRecurring] = useState(expense?.is_recurring ?? false)
  const [recurringFrequency, setRecurringFrequency] = useState<string>(
    expense?.recurring_frequency ?? 'monthly'
  )
  const [screenshotUrl, setScreenshotUrl] = useState(expense?.screenshot_url ?? '')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleExtractedData = (data: {
    amount?: number
    description?: string
    date?: string
    merchant?: string
  }) => {
    if (data.amount) setAmount(data.amount.toString())
    if (data.description) setDescription(data.description)
    if (data.merchant) setDescription(data.merchant)
    if (data.date) setExpenseDate(data.date)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!amount || Number(amount) <= 0) {
      setError('Please enter a valid amount')
      return
    }

    setIsLoading(true)

    const supabase = createClient()

    const expenseData = {
      user_id: userId,
      amount: Number(amount),
      description: description || null,
      category_id: categoryId || null,
      payment_method: paymentMethod,
      expense_date: expenseDate,
      is_recurring: isRecurring,
      recurring_frequency: isRecurring ? recurringFrequency : null,
      screenshot_url: screenshotUrl || null,
    }

    if (isEditing && expense) {
      const { error } = await supabase
        .from('expenses')
        .update(expenseData)
        .eq('id', expense.id)

      if (error) {
        setError(error.message)
        setIsLoading(false)
        return
      }
    } else {
      const { error } = await supabase.from('expenses').insert(expenseData)

      if (error) {
        setError(error.message)
        setIsLoading(false)
        return
      }
    }

    router.push('/dashboard/expenses')
    router.refresh()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Screenshot Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Screenshot (Optional)</CardTitle>
        </CardHeader>
        <CardContent>
          <ScreenshotUpload
            onUpload={(url) => setScreenshotUrl(url)}
            onExtract={handleExtractedData}
            currentUrl={screenshotUrl}
          />
        </CardContent>
      </Card>

      {/* Main Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Expense Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <div className="flex items-center gap-2 rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
              <AlertCircle className="h-4 w-4" />
              {error}
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount (PKR) *</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
                min="1"
                step="1"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Date *</Label>
              <Input
                id="date"
                type="date"
                value={expenseDate}
                onChange={(e) => setExpenseDate(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="What was this expense for?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select value={categoryId} onValueChange={setCategoryId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      <div className="flex items-center gap-2">
                        <div
                          className="h-3 w-3 rounded-full"
                          style={{ backgroundColor: cat.color }}
                        />
                        {cat.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="payment">Payment Method</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((method) => (
                    <SelectItem key={method.value} value={method.value}>
                      {method.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <Label htmlFor="recurring">Recurring Expense</Label>
              <p className="text-sm text-muted-foreground">
                Mark if this is a regular expense
              </p>
            </div>
            <Switch
              id="recurring"
              checked={isRecurring}
              onCheckedChange={setIsRecurring}
            />
          </div>

          {isRecurring && (
            <div className="space-y-2">
              <Label htmlFor="frequency">Frequency</Label>
              <Select value={recurringFrequency} onValueChange={setRecurringFrequency}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {RECURRING_FREQUENCIES.map((freq) => (
                    <SelectItem key={freq.value} value={freq.value}>
                      {freq.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => router.back()}
          disabled={isLoading}
        >
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading} className="flex-1">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {isEditing ? 'Updating...' : 'Saving...'}
            </>
          ) : isEditing ? (
            'Update Expense'
          ) : (
            'Save Expense'
          )}
        </Button>
      </div>
    </form>
  )
}
