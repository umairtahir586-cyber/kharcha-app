'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { formatPKR } from '@/lib/format'
import { Trash2, AlertTriangle } from 'lucide-react'
import type { Budget, Category } from '@/lib/types'

interface BudgetWithCategory extends Budget {
  category: Category
}

interface BudgetListProps {
  budgets: BudgetWithCategory[]
  categorySpending: Record<string, number>
}

export function BudgetList({ budgets, categorySpending }: BudgetListProps) {
  const router = useRouter()
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  const handleDelete = async () => {
    if (!deleteId) return
    setIsDeleting(true)

    const supabase = createClient()
    await supabase.from('budgets').delete().eq('id', deleteId)

    setDeleteId(null)
    setIsDeleting(false)
    router.refresh()
  }

  if (budgets.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <p className="text-muted-foreground text-center">
            No budgets set yet. Create your first budget to start tracking!
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <div className="space-y-4">
        {budgets.map((budget) => {
          const spent = categorySpending[budget.category_id] ?? 0
          const percentage = Math.min((spent / Number(budget.amount)) * 100, 100)
          const isOverBudget = spent > Number(budget.amount)
          const remaining = Number(budget.amount) - spent

          return (
            <Card key={budget.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="h-10 w-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${budget.category.color}20` }}
                    >
                      <div
                        className="h-4 w-4 rounded-full"
                        style={{ backgroundColor: budget.category.color }}
                      />
                    </div>
                    <div>
                      <h3 className="font-semibold">{budget.category.name}</h3>
                      <p className="text-sm text-muted-foreground capitalize">
                        {budget.period} budget
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-muted-foreground hover:text-destructive"
                    onClick={() => setDeleteId(budget.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>{formatPKR(spent)} spent</span>
                    <span className="text-muted-foreground">
                      of {formatPKR(Number(budget.amount))}
                    </span>
                  </div>
                  <Progress
                    value={percentage}
                    className={`h-3 ${isOverBudget ? '[&>div]:bg-destructive' : ''}`}
                  />
                  <div className="flex items-center justify-between">
                    {isOverBudget ? (
                      <div className="flex items-center gap-1 text-destructive text-sm">
                        <AlertTriangle className="h-4 w-4" />
                        <span>Over by {formatPKR(Math.abs(remaining))}</span>
                      </div>
                    ) : (
                      <span className="text-sm text-muted-foreground">
                        {formatPKR(remaining)} remaining
                      </span>
                    )}
                    <span className="text-sm font-medium">
                      {percentage.toFixed(0)}%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Budget</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this budget? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={isDeleting}
            >
              {isDeleting ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
