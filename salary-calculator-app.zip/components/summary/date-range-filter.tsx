'use client'

import { useRouter, usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import {
  getStartOfMonth,
  getEndOfMonth,
  getStartOfLastMonth,
  getEndOfLastMonth,
  getStartOfWeek,
  toISODateString,
} from '@/lib/format'
import { Calendar } from 'lucide-react'

interface DateRangeFilterProps {
  startDate: string
  endDate: string
  preset: string
}

const presets = [
  { value: 'today', label: 'Today' },
  { value: 'yesterday', label: 'Yesterday' },
  { value: 'this_week', label: 'This Week' },
  { value: 'this_month', label: 'This Month' },
  { value: 'last_month', label: 'Last Month' },
  { value: 'custom', label: 'Custom' },
]

export function DateRangeFilter({ startDate, endDate, preset }: DateRangeFilterProps) {
  const router = useRouter()
  const pathname = usePathname()

  const applyPreset = (presetValue: string) => {
    const today = new Date()
    let start: Date
    let end: Date

    switch (presetValue) {
      case 'today':
        start = today
        end = today
        break
      case 'yesterday':
        const yesterday = new Date(today)
        yesterday.setDate(yesterday.getDate() - 1)
        start = yesterday
        end = yesterday
        break
      case 'this_week':
        start = getStartOfWeek()
        end = today
        break
      case 'this_month':
        start = getStartOfMonth()
        end = getEndOfMonth()
        break
      case 'last_month':
        start = getStartOfLastMonth()
        end = getEndOfLastMonth()
        break
      default:
        return
    }

    const params = new URLSearchParams()
    params.set('start', toISODateString(start))
    params.set('end', toISODateString(end))
    params.set('preset', presetValue)
    router.push(`${pathname}?${params.toString()}`)
  }

  const updateDateRange = (start: string, end: string) => {
    const params = new URLSearchParams()
    params.set('start', start)
    params.set('end', end)
    params.set('preset', 'custom')
    router.push(`${pathname}?${params.toString()}`)
  }

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap gap-2">
            {presets.map((p) => (
              <Button
                key={p.value}
                variant={preset === p.value ? 'default' : 'outline'}
                size="sm"
                onClick={() => p.value !== 'custom' && applyPreset(p.value)}
                className={p.value === 'custom' ? 'hidden sm:inline-flex' : ''}
              >
                {p.label}
              </Button>
            ))}
          </div>
          
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground hidden sm:block" />
            <Input
              type="date"
              value={startDate}
              onChange={(e) => updateDateRange(e.target.value, endDate)}
              className="w-[140px]"
            />
            <span className="text-muted-foreground">to</span>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => updateDateRange(startDate, e.target.value)}
              className="w-[140px]"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
