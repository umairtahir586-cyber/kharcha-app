'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { formatPKR, calculatePercentageChange, formatDate } from '@/lib/format'
import { TrendingUp, TrendingDown, Minus, Receipt, Calendar } from 'lucide-react'

interface PeriodComparisonProps {
  currentTotal: number
  previousTotal: number
  currentPeriod: { start: string; end: string }
  transactionCount: number
}

export function PeriodComparison({
  currentTotal,
  previousTotal,
  currentPeriod,
  transactionCount,
}: PeriodComparisonProps) {
  const percentageChange = calculatePercentageChange(currentTotal, previousTotal)
  const isIncrease = percentageChange > 0
  const isDecrease = percentageChange < 0
  const isNoChange = percentageChange === 0

  return (
    <div className="grid gap-4 sm:grid-cols-3">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-muted-foreground">
              Total Spent
            </p>
            <div className="rounded-full bg-primary/10 p-2">
              <Receipt className="h-4 w-4 text-primary" />
            </div>
          </div>
          <p className="mt-2 text-2xl font-bold">{formatPKR(currentTotal)}</p>
          <p className="mt-1 text-xs text-muted-foreground">
            {transactionCount} transaction{transactionCount !== 1 ? 's' : ''}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-muted-foreground">
              vs Previous Period
            </p>
            <div
              className={`rounded-full p-2 ${
                isIncrease
                  ? 'bg-red-100 text-red-600'
                  : isDecrease
                  ? 'bg-green-100 text-green-600'
                  : 'bg-muted text-muted-foreground'
              }`}
            >
              {isIncrease ? (
                <TrendingUp className="h-4 w-4" />
              ) : isDecrease ? (
                <TrendingDown className="h-4 w-4" />
              ) : (
                <Minus className="h-4 w-4" />
              )}
            </div>
          </div>
          <p className="mt-2 text-2xl font-bold">
            {isNoChange ? '0%' : `${isIncrease ? '+' : ''}${percentageChange}%`}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Previous: {formatPKR(previousTotal)}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-muted-foreground">
              Daily Average
            </p>
            <div className="rounded-full bg-primary/10 p-2">
              <Calendar className="h-4 w-4 text-primary" />
            </div>
          </div>
          {(() => {
            const start = new Date(currentPeriod.start)
            const end = new Date(currentPeriod.end)
            const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1
            const dailyAvg = days > 0 ? currentTotal / days : 0
            return (
              <>
                <p className="mt-2 text-2xl font-bold">{formatPKR(dailyAvg)}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Over {days} day{days !== 1 ? 's' : ''}
                </p>
              </>
            )
          })()}
        </CardContent>
      </Card>
    </div>
  )
}
