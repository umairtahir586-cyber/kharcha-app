'use client'

import { useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { formatPKR, getPaymentMethodLabel } from '@/lib/format'
import { Banknote, CreditCard, Smartphone, Building } from 'lucide-react'
import type { ExpenseWithCategory } from '@/lib/types'

interface PaymentMethodSummaryProps {
  expenses: ExpenseWithCategory[]
}

const methodIcons = {
  cash: Banknote,
  card: CreditCard,
  online: Smartphone,
  bank_transfer: Building,
}

const methodColors = {
  cash: '#10b981',
  card: '#3b82f6',
  online: '#8b5cf6',
  bank_transfer: '#f59e0b',
}

export function PaymentMethodSummary({ expenses }: PaymentMethodSummaryProps) {
  const methodSummaries = useMemo(() => {
    const totals = new Map<string, { total: number; count: number }>()

    expenses.forEach((expense) => {
      const method = expense.payment_method
      const existing = totals.get(method) ?? { total: 0, count: 0 }
      totals.set(method, {
        total: existing.total + Number(expense.amount),
        count: existing.count + 1,
      })
    })

    const totalSpent = expenses.reduce((sum, e) => sum + Number(e.amount), 0)

    return Array.from(totals.entries())
      .map(([method, data]) => ({
        method,
        label: getPaymentMethodLabel(method),
        icon: methodIcons[method as keyof typeof methodIcons] ?? Banknote,
        color: methodColors[method as keyof typeof methodColors] ?? '#6b7280',
        total: data.total,
        count: data.count,
        percentage: totalSpent > 0 ? (data.total / totalSpent) * 100 : 0,
      }))
      .sort((a, b) => b.total - a.total)
  }, [expenses])

  if (methodSummaries.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>By Payment Method</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-8">
            No expenses to analyze
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>By Payment Method</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {methodSummaries.map((method) => {
          const Icon = method.icon
          return (
            <div key={method.method} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className="flex h-8 w-8 items-center justify-center rounded-lg"
                    style={{ backgroundColor: `${method.color}20` }}
                  >
                    <Icon className="h-4 w-4" style={{ color: method.color }} />
                  </div>
                  <div>
                    <span className="text-sm font-medium">{method.label}</span>
                    <p className="text-xs text-muted-foreground">
                      {method.count} transaction{method.count !== 1 ? 's' : ''}
                    </p>
                  </div>
                </div>
                <span className="text-sm font-semibold">{formatPKR(method.total)}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-3 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${method.percentage}%`,
                      backgroundColor: method.color,
                    }}
                  />
                </div>
                <span className="text-xs text-muted-foreground w-12 text-right">
                  {method.percentage.toFixed(1)}%
                </span>
              </div>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
