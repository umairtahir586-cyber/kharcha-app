'use client'

import { useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { formatPKR } from '@/lib/format'
import type { ExpenseWithCategory, Category } from '@/lib/types'

interface CategorySummaryProps {
  expenses: ExpenseWithCategory[]
  categories: Category[]
}

export function CategorySummary({ expenses, categories }: CategorySummaryProps) {
  const categorySummaries = useMemo(() => {
    const totals = new Map<string, { total: number; count: number }>()

    expenses.forEach((expense) => {
      const catId = expense.category_id ?? 'uncategorized'
      const existing = totals.get(catId) ?? { total: 0, count: 0 }
      totals.set(catId, {
        total: existing.total + Number(expense.amount),
        count: existing.count + 1,
      })
    })

    const totalSpent = expenses.reduce((sum, e) => sum + Number(e.amount), 0)

    return Array.from(totals.entries())
      .map(([catId, data]) => {
        const category = categories.find((c) => c.id === catId)
        return {
          id: catId,
          name: category?.name ?? 'Uncategorized',
          color: category?.color ?? '#6b7280',
          total: data.total,
          count: data.count,
          percentage: totalSpent > 0 ? (data.total / totalSpent) * 100 : 0,
        }
      })
      .sort((a, b) => b.total - a.total)
  }, [expenses, categories])

  if (categorySummaries.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>By Category</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-8">
            No expenses to categorize
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>By Category</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {categorySummaries.map((cat) => (
          <div key={cat.id} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div
                  className="h-3 w-3 rounded-full"
                  style={{ backgroundColor: cat.color }}
                />
                <span className="text-sm font-medium">{cat.name}</span>
                <span className="text-xs text-muted-foreground">
                  ({cat.count})
                </span>
              </div>
              <span className="text-sm font-semibold">{formatPKR(cat.total)}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-3 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all"
                  style={{ 
                    width: `${cat.percentage}%`,
                    backgroundColor: cat.color,
                  }}
                />
              </div>
              <span className="text-xs text-muted-foreground w-12 text-right">
                {cat.percentage.toFixed(1)}%
              </span>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
