'use client'

import { useMemo, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { formatPKR, getRelativeDate, formatDate, getPaymentMethodLabel } from '@/lib/format'
import { ChevronDown, ChevronUp } from 'lucide-react'
import type { ExpenseWithCategory } from '@/lib/types'

interface DailyBreakdownProps {
  expenses: ExpenseWithCategory[]
  startDate: string
  endDate: string
}

export function DailyBreakdown({ expenses, startDate, endDate }: DailyBreakdownProps) {
  const [expandedDays, setExpandedDays] = useState<Set<string>>(new Set())

  const dailySummaries = useMemo(() => {
    // Group expenses by date
    const byDate = new Map<string, ExpenseWithCategory[]>()
    
    // Initialize all dates in range
    const start = new Date(startDate)
    const end = new Date(endDate)
    for (let d = new Date(end); d >= start; d.setDate(d.getDate() - 1)) {
      const dateStr = d.toISOString().split('T')[0]
      byDate.set(dateStr, [])
    }

    // Populate with expenses
    expenses.forEach((expense) => {
      const existing = byDate.get(expense.expense_date) ?? []
      byDate.set(expense.expense_date, [...existing, expense])
    })

    return Array.from(byDate.entries())
      .map(([date, dayExpenses]) => ({
        date,
        total: dayExpenses.reduce((sum, e) => sum + Number(e.amount), 0),
        count: dayExpenses.length,
        expenses: dayExpenses,
      }))
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  }, [expenses, startDate, endDate])

  const toggleDay = (date: string) => {
    const newExpanded = new Set(expandedDays)
    if (newExpanded.has(date)) {
      newExpanded.delete(date)
    } else {
      newExpanded.add(date)
    }
    setExpandedDays(newExpanded)
  }

  const maxTotal = Math.max(...dailySummaries.map((d) => d.total), 1)

  if (dailySummaries.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Daily Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-8">
            No expenses in the selected date range
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Daily Breakdown</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {dailySummaries.map((day) => {
          const isExpanded = expandedDays.has(day.date)
          const barWidth = maxTotal > 0 ? (day.total / maxTotal) * 100 : 0

          return (
            <div key={day.date} className="border rounded-lg overflow-hidden">
              <button
                onClick={() => day.count > 0 && toggleDay(day.date)}
                className={`w-full p-4 flex items-center justify-between hover:bg-muted/50 transition-colors ${
                  day.count === 0 ? 'opacity-50' : ''
                }`}
                disabled={day.count === 0}
              >
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{getRelativeDate(day.date)}</span>
                      <span className="text-sm text-muted-foreground">
                        {formatDate(day.date)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">
                        {day.total > 0 ? formatPKR(day.total) : '-'}
                      </span>
                      {day.count > 0 && (
                        isExpanded ? (
                          <ChevronUp className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        )
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full transition-all"
                        style={{ width: `${barWidth}%` }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground w-24 text-right">
                      {day.count} item{day.count !== 1 ? 's' : ''}
                    </span>
                  </div>
                </div>
              </button>

              {isExpanded && day.expenses.length > 0 && (
                <div className="border-t bg-muted/30 divide-y">
                  {day.expenses.map((expense) => (
                    <div
                      key={expense.id}
                      className="flex items-center justify-between px-4 py-3"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="h-3 w-3 rounded-full"
                          style={{
                            backgroundColor: expense.category?.color ?? '#6b7280',
                          }}
                        />
                        <div>
                          <p className="text-sm font-medium">
                            {expense.description ?? expense.category?.name ?? 'Expense'}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {expense.category?.name ?? 'Uncategorized'} • {getPaymentMethodLabel(expense.payment_method)}
                          </p>
                        </div>
                      </div>
                      <span className="font-medium text-sm">
                        {formatPKR(Number(expense.amount))}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
