'use client'

import { Card, CardContent } from '@/components/ui/card'
import { formatPKR } from '@/lib/format'
import { TrendingUp, TrendingDown, Wallet, Calendar, Receipt, PiggyBank } from 'lucide-react'

interface StatsCardsProps {
  totalMonthly: number
  totalToday: number
  salary: number
  remaining: number
  transactionCount: number
}

export function StatsCards({
  totalMonthly,
  totalToday,
  salary,
  remaining,
  transactionCount,
}: StatsCardsProps) {
  const stats = [
    {
      title: 'Monthly Salary',
      value: formatPKR(salary),
      icon: Wallet,
      description: salary > 0 ? 'Your income this month' : 'Set in settings',
      trend: null,
    },
    {
      title: 'Total Spent',
      value: formatPKR(totalMonthly),
      icon: TrendingDown,
      description: `${transactionCount} transactions`,
      trend: 'negative' as const,
    },
    {
      title: "Today's Expenses",
      value: formatPKR(totalToday),
      icon: Calendar,
      description: 'Spent today',
      trend: null,
    },
    {
      title: 'Remaining',
      value: formatPKR(remaining),
      icon: remaining >= 0 ? PiggyBank : TrendingDown,
      description: remaining >= 0 ? 'Left to spend' : 'Over budget!',
      trend: remaining >= 0 ? ('positive' as const) : ('negative' as const),
    },
  ]

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.title}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
              <div
                className={`rounded-full p-2 ${
                  stat.trend === 'positive'
                    ? 'bg-green-100 text-green-600'
                    : stat.trend === 'negative'
                    ? 'bg-red-100 text-red-600'
                    : 'bg-primary/10 text-primary'
                }`}
              >
                <stat.icon className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-2">
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
