'use client'

import { useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { formatPKR } from '@/lib/format'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import type { ExpenseWithCategory } from '@/lib/types'

interface ExpenseChartProps {
  expenses: ExpenseWithCategory[]
}

export function ExpenseChart({ expenses }: ExpenseChartProps) {
  const chartData = useMemo(() => {
    const dailyTotals = new Map<string, number>()
    
    // Get last 14 days
    const today = new Date()
    for (let i = 13; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(date.getDate() - i)
      const dateStr = date.toISOString().split('T')[0]
      dailyTotals.set(dateStr, 0)
    }

    // Sum expenses by day
    expenses.forEach((expense) => {
      const existing = dailyTotals.get(expense.expense_date) ?? 0
      dailyTotals.set(expense.expense_date, existing + Number(expense.amount))
    })

    return Array.from(dailyTotals.entries()).map(([date, total]) => ({
      date,
      total,
      label: new Date(date).toLocaleDateString('en-PK', { 
        weekday: 'short', 
        day: 'numeric' 
      }),
    }))
  }, [expenses])

  const maxValue = Math.max(...chartData.map(d => d.total), 1000)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Daily Spending (Last 14 Days)</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
              <XAxis 
                dataKey="label" 
                tick={{ fontSize: 12 }} 
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                tick={{ fontSize: 12 }} 
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                domain={[0, maxValue]}
              />
              <Tooltip
                formatter={(value: number) => [formatPKR(value), 'Spent']}
                labelStyle={{ fontWeight: 'bold' }}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Bar 
                dataKey="total" 
                fill="#0d9488"
                radius={[4, 4, 0, 0]}
                maxBarSize={40}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
