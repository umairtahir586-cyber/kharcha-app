'use client'

import { useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { formatPKR } from '@/lib/format'
import type { ExpenseWithCategory, Category, Budget } from '@/lib/types'

interface CategoryBreakdownProps {
  expenses: ExpenseWithCategory[]
  categories: Category[]
  budgets: Budget[]
}

export function CategoryBreakdown({ expenses, categories, budgets }: CategoryBreakdownProps) {
  const categoryTotals = useMemo(() => {
    const totals = new Map<string, { total: number; count: number }>()
    
    expenses.forEach((expense) => {
      const catId = expense.category_id ?? 'uncategorized'
      const existing = totals.get(catId) ?? { total: 0, count: 0 }
      totals.set(catId, {
        total: existing.total + Number(expense.amount),
        count: existing.count + 1,
      })
    })

    const totalSpent = expenses.reduce((sum, e) => sum + Number(e.amount), 0)

    return Array.from(totals.entries())
      .map(([catId, data]) => {
        const category = categories.find((c) => c.id === catId)
        const budget = budgets.find((b) => b.category_id === catId)
        return {
          id: catId,
          name: category?.name ?? 'Uncategorized',
          color: category?.color ?? '#6b7280',
          total: data.total,
          count: data.count,
          percentage: totalSpent > 0 ? (data.total / totalSpent) * 100 : 0,
          budget: budget?.amount ?? null,
        }
      })
      .sort((a, b) => b.total - a.total)
      .slice(0, 6)
  }, [expenses, categories, budgets])

  if (categoryTotals.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>By Category</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-8">
            No expenses recorded this month
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>By Category</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {categoryTotals.map((cat) => {
          const budgetPercentage = cat.budget
            ? Math.min((cat.total / Number(cat.budget)) * 100, 100)
            : null
          const isOverBudget = cat.budget && cat.total > Number(cat.budget)

          return (
            <div key={cat.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className="h-3 w-3 rounded-full"
                    style={{ backgroundColor: cat.color }}
                  />
                  <span className="text-sm font-medium">{cat.name}</span>
                </div>
                <span className="text-sm font-semibold">{formatPKR(cat.total)}</span>
              </div>
              <div className="flex items-center gap-2">
                <Progress
                  value={cat.percentage}
                  className="h-2 flex-1"
                  style={
                    {
                      '--progress-background': cat.color,
                    } as React.CSSProperties
                  }
                />
                <span className="text-xs text-muted-foreground w-12 text-right">
                  {cat.percentage.toFixed(0)}%
                </span>
              </div>
              {cat.budget && (
                <div className="flex items-center justify-between text-xs">
                  <span className={isOverBudget ? 'text-destructive' : 'text-muted-foreground'}>
                    {isOverBudget ? 'Over budget!' : `Budget: ${formatPKR(Number(cat.budget))}`}
                  </span>
                  <span className="text-muted-foreground">
                    {budgetPercentage?.toFixed(0)}% used
                  </span>
                </div>
              )}
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
