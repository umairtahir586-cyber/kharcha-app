'use client'

import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { formatPKR, formatDate, getPaymentMethodLabel } from '@/lib/format'
import { ArrowRight, Banknote, CreditCard, Smartphone, Building } from 'lucide-react'
import type { ExpenseWithCategory } from '@/lib/types'

interface RecentTransactionsProps {
  expenses: ExpenseWithCategory[]
}

const paymentIcons = {
  cash: Banknote,
  card: CreditCard,
  online: Smartphone,
  bank_transfer: Building,
}

export function RecentTransactions({ expenses }: RecentTransactionsProps) {
  if (expenses.length === 0) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Recent Transactions</CardTitle>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/dashboard/expenses/new">
              Add First Expense
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-8">
            No expenses recorded yet. Start tracking your spending!
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Recent Transactions</CardTitle>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/dashboard/expenses">
            View All
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {expenses.map((expense) => {
            const PaymentIcon = paymentIcons[expense.payment_method] ?? Banknote
            return (
              <div
                key={expense.id}
                className="flex items-center justify-between py-2 border-b last:border-0"
              >
                <div className="flex items-center gap-3">
                  <div
                    className="flex h-10 w-10 items-center justify-center rounded-full"
                    style={{
                      backgroundColor: expense.category?.color
                        ? `${expense.category.color}20`
                        : '#f3f4f6',
                    }}
                  >
                    <PaymentIcon
                      className="h-5 w-5"
                      style={{ color: expense.category?.color ?? '#6b7280' }}
                    />
                  </div>
                  <div>
                    <p className="font-medium text-sm">
                      {expense.description ?? expense.category?.name ?? 'Expense'}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {expense.category?.name ?? 'Uncategorized'} • {formatDate(expense.expense_date)}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-destructive">-{formatPKR(Number(expense.amount))}</p>
                  <p className="text-xs text-muted-foreground">
                    {getPaymentMethodLabel(expense.payment_method)}
                  </p>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
