import Link from 'next/link'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { Button } from '@/components/ui/button'
import { Wallet, TrendingUp, Receipt, PieChart, Camera, ArrowRight } from 'lucide-react'

export default async function HomePage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (user) {
    redirect('/dashboard')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-primary/10">
      <header className="container mx-auto px-4 py-6">
        <nav className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <Wallet className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">Kharcha</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" asChild>
              <Link href="/auth/login">Sign in</Link>
            </Button>
            <Button asChild>
              <Link href="/auth/sign-up">Get Started</Link>
            </Button>
          </div>
        </nav>
      </header>

      <main className="container mx-auto px-4 py-16">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl text-balance">
            Track Every Rupee,{' '}
            <span className="text-primary">Master Your Money</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground text-pretty">
            Your personal salary calculator and expense tracker. Record bills, invoices, daily expenses, 
            and online payments. Just attach a screenshot and let AI extract the details for you.
          </p>
          <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <Button size="lg" asChild>
              <Link href="/auth/sign-up">
                Start Tracking Free
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/auth/login">I have an account</Link>
            </Button>
          </div>
        </div>

        <div className="mt-24 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <FeatureCard
            icon={Receipt}
            title="Record Everything"
            description="Track bills, invoices, daily expenses, and online payments in one place"
          />
          <FeatureCard
            icon={Camera}
            title="AI Screenshot Reader"
            description="Attach payment screenshots and let AI automatically extract expense details"
          />
          <FeatureCard
            icon={PieChart}
            title="Date-wise Summary"
            description="See exactly how much you spent today, yesterday, and any date range"
          />
          <FeatureCard
            icon={TrendingUp}
            title="Budget Tracking"
            description="Set monthly budgets by category and get alerts when you exceed them"
          />
        </div>

        <div className="mt-24 rounded-2xl border bg-card p-8 text-center">
          <p className="text-3xl font-bold text-primary">PKR</p>
          <p className="mt-2 text-muted-foreground">
            Designed for Pakistani Rupee with local formatting
          </p>
        </div>
      </main>

      <footer className="container mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
        <p>Built with care for managing your finances</p>
      </footer>
    </div>
  )
}

function FeatureCard({ 
  icon: Icon, 
  title, 
  description 
}: { 
  icon: React.ComponentType<{ className?: string }>
  title: string
  description: string 
}) {
  return (
    <div className="rounded-xl border bg-card p-6 transition-shadow hover:shadow-md">
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
        <Icon className="h-6 w-6 text-primary" />
      </div>
      <h3 className="font-semibold">{title}</h3>
      <p className="mt-2 text-sm text-muted-foreground">{description}</p>
    </div>
  )
}
