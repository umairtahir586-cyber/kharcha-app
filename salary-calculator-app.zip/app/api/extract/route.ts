import { generateText, Output } from 'ai'
import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { z } from 'zod'

const extractionSchema = z.object({
  amount: z.number().nullable().describe('The total amount in PKR (Pakistani Rupees). Extract just the number without currency symbol.'),
  description: z.string().nullable().describe('A brief description of what the payment was for'),
  merchant: z.string().nullable().describe('The name of the merchant or store'),
  date: z.string().nullable().describe('The date of the transaction in YYYY-MM-DD format'),
})

export async function POST(request: Request) {
  try {
    // Verify user is authenticated
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { imageUrl } = await request.json()

    if (!imageUrl) {
      return NextResponse.json({ error: 'No image URL provided' }, { status: 400 })
    }

    const result = await generateText({
      model: 'google/gemini-2.0-flash-001',
      output: Output.object({ schema: extractionSchema }),
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: `Analyze this payment/expense screenshot and extract the following information:
1. Amount: The total amount paid (in PKR if possible, or convert to PKR if you can identify the currency)
2. Description: What was this payment for
3. Merchant: The name of the store/service/person paid
4. Date: The date of the transaction

If you cannot find a specific field, return null for that field. For the date, format it as YYYY-MM-DD.`,
            },
            {
              type: 'image',
              image: imageUrl,
            },
          ],
        },
      ],
    })

    const extracted = result.output

    return NextResponse.json({
      amount: extracted?.amount ?? null,
      description: extracted?.description ?? extracted?.merchant ?? null,
      merchant: extracted?.merchant ?? null,
      date: extracted?.date ?? null,
    })
  } catch (error) {
    console.error('Extraction error:', error)
    return NextResponse.json({ error: 'Failed to extract data' }, { status: 500 })
  }
}
