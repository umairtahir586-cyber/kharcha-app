import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { Button } from '@/components/ui/button'
import { Plus } from 'lucide-react'
import { ExpenseList } from '@/components/expenses/expense-list'
import { ExpenseFilters } from '@/components/expenses/expense-filters'

export default async function ExpensesPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const params = await searchParams
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  // Get filter parameters
  const categoryFilter = typeof params.category === 'string' ? params.category : undefined
  const paymentFilter = typeof params.payment === 'string' ? params.payment : undefined
  const startDate = typeof params.start === 'string' ? params.start : undefined
  const endDate = typeof params.end === 'string' ? params.end : undefined

  // Build query
  let query = supabase
    .from('expenses')
    .select('*, category:categories(*)')
    .eq('user_id', user.id)
    .order('expense_date', { ascending: false })
    .order('created_at', { ascending: false })

  if (categoryFilter) {
    query = query.eq('category_id', categoryFilter)
  }
  if (paymentFilter) {
    query = query.eq('payment_method', paymentFilter)
  }
  if (startDate) {
    query = query.gte('expense_date', startDate)
  }
  if (endDate) {
    query = query.lte('expense_date', endDate)
  }

  const { data: expenses } = await query

  // Get categories for filter
  const { data: categories } = await supabase
    .from('categories')
    .select('*')
    .eq('user_id', user.id)
    .order('name')

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Expenses</h1>
          <p className="text-muted-foreground">
            Manage and track all your expenses
          </p>
        </div>
        <Button asChild>
          <Link href="/dashboard/expenses/new">
            <Plus className="mr-2 h-4 w-4" />
            Add Expense
          </Link>
        </Button>
      </div>

      <ExpenseFilters categories={categories ?? []} />

      <ExpenseList expenses={expenses ?? []} categories={categories ?? []} />
    </div>
  )
}
