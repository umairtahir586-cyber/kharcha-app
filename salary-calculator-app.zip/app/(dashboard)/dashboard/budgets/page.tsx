import { createClient } from '@/lib/supabase/server'
import { BudgetList } from '@/components/budgets/budget-list'
import { BudgetForm } from '@/components/budgets/budget-form'
import { getStartOfMonth, getEndOfMonth, toISODateString } from '@/lib/format'

export default async function BudgetsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  // Get categories
  const { data: categories } = await supabase
    .from('categories')
    .select('*')
    .eq('user_id', user.id)
    .order('name')

  // Get budgets with categories
  const { data: budgets } = await supabase
    .from('budgets')
    .select('*, category:categories(*)')
    .eq('user_id', user.id)

  // Get this month's expenses by category
  const startOfMonth = toISODateString(getStartOfMonth())
  const endOfMonth = toISODateString(getEndOfMonth())

  const { data: expenses } = await supabase
    .from('expenses')
    .select('category_id, amount')
    .eq('user_id', user.id)
    .gte('expense_date', startOfMonth)
    .lte('expense_date', endOfMonth)

  // Calculate spending per category
  const categorySpending = new Map<string, number>()
  expenses?.forEach((e) => {
    if (e.category_id) {
      const current = categorySpending.get(e.category_id) ?? 0
      categorySpending.set(e.category_id, current + Number(e.amount))
    }
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Budgets</h1>
        <p className="text-muted-foreground">
          Set spending limits by category and track your progress
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <BudgetList 
            budgets={budgets ?? []} 
            categorySpending={Object.fromEntries(categorySpending)}
          />
        </div>
        <div>
          <BudgetForm 
            categories={categories ?? []} 
            existingBudgets={budgets ?? []}
            userId={user.id}
          />
        </div>
      </div>
    </div>
  )
}
