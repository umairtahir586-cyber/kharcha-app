import { createClient } from '@/lib/supabase/server'
import { StatsCards } from '@/components/dashboard/stats-cards'
import { ExpenseChart } from '@/components/dashboard/expense-chart'
import { CategoryBreakdown } from '@/components/dashboard/category-breakdown'
import { RecentTransactions } from '@/components/dashboard/recent-transactions'
import { getStartOfMonth, getEndOfMonth, toISODateString } from '@/lib/format'

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  const startOfMonth = toISODateString(getStartOfMonth())
  const endOfMonth = toISODateString(getEndOfMonth())
  const today = toISODateString(new Date())

  // Get this month's expenses
  const { data: monthlyExpenses } = await supabase
    .from('expenses')
    .select('*, category:categories(*)')
    .eq('user_id', user.id)
    .gte('expense_date', startOfMonth)
    .lte('expense_date', endOfMonth)
    .order('expense_date', { ascending: false })

  // Get today's expenses
  const { data: todayExpenses } = await supabase
    .from('expenses')
    .select('amount')
    .eq('user_id', user.id)
    .eq('expense_date', today)

  // Get profile for salary
  const { data: profile } = await supabase
    .from('profiles')
    .select('monthly_salary')
    .eq('id', user.id)
    .single()

  // Get categories for breakdown
  const { data: categories } = await supabase
    .from('categories')
    .select('*')
    .eq('user_id', user.id)

  // Get budgets
  const { data: budgets } = await supabase
    .from('budgets')
    .select('*, category:categories(*)')
    .eq('user_id', user.id)

  const totalMonthly = monthlyExpenses?.reduce((sum, e) => sum + Number(e.amount), 0) ?? 0
  const totalToday = todayExpenses?.reduce((sum, e) => sum + Number(e.amount), 0) ?? 0
  const salary = profile?.monthly_salary ?? 0
  const remaining = salary - totalMonthly

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Your financial overview for this month
        </p>
      </div>

      <StatsCards
        totalMonthly={totalMonthly}
        totalToday={totalToday}
        salary={salary}
        remaining={remaining}
        transactionCount={monthlyExpenses?.length ?? 0}
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <ExpenseChart expenses={monthlyExpenses ?? []} />
        </div>
        <div>
          <CategoryBreakdown 
            expenses={monthlyExpenses ?? []} 
            categories={categories ?? []}
            budgets={budgets ?? []}
          />
        </div>
      </div>

      <RecentTransactions expenses={monthlyExpenses?.slice(0, 10) ?? []} />
    </div>
  )
}
