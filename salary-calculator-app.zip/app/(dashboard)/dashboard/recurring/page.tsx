import { createClient } from '@/lib/supabase/server'
import { RecurringList } from '@/components/recurring/recurring-list'

export default async function RecurringPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  // Get recurring expenses
  const { data: recurringExpenses } = await supabase
    .from('expenses')
    .select('*, category:categories(*)')
    .eq('user_id', user.id)
    .eq('is_recurring', true)
    .order('expense_date', { ascending: false })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Recurring Expenses</h1>
        <p className="text-muted-foreground">
          Track your regular bills and subscriptions
        </p>
      </div>

      <RecurringList expenses={recurringExpenses ?? []} />
    </div>
  )
}
