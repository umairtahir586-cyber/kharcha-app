import { createClient } from '@/lib/supabase/server'
import { DateRangeFilter } from '@/components/summary/date-range-filter'
import { DailyBreakdown } from '@/components/summary/daily-breakdown'
import { CategorySummary } from '@/components/summary/category-summary'
import { PaymentMethodSummary } from '@/components/summary/payment-method-summary'
import { PeriodComparison } from '@/components/summary/period-comparison'
import { 
  getStartOfMonth, 
  getEndOfMonth, 
  getStartOfLastMonth, 
  getEndOfLastMonth,
  toISODateString 
} from '@/lib/format'

export default async function SummaryPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const params = await searchParams
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return null

  // Parse date range from search params
  const today = new Date()
  const defaultStart = toISODateString(getStartOfMonth())
  const defaultEnd = toISODateString(getEndOfMonth())
  
  const startDate = typeof params.start === 'string' ? params.start : defaultStart
  const endDate = typeof params.end === 'string' ? params.end : defaultEnd
  const preset = typeof params.preset === 'string' ? params.preset : 'this_month'

  // Get expenses for selected period
  const { data: expenses } = await supabase
    .from('expenses')
    .select('*, category:categories(*)')
    .eq('user_id', user.id)
    .gte('expense_date', startDate)
    .lte('expense_date', endDate)
    .order('expense_date', { ascending: false })
    .order('created_at', { ascending: false })

  // Get expenses for previous period (for comparison)
  const startDateObj = new Date(startDate)
  const endDateObj = new Date(endDate)
  const periodDays = Math.ceil((endDateObj.getTime() - startDateObj.getTime()) / (1000 * 60 * 60 * 24)) + 1
  
  const prevEndDate = new Date(startDateObj)
  prevEndDate.setDate(prevEndDate.getDate() - 1)
  const prevStartDate = new Date(prevEndDate)
  prevStartDate.setDate(prevStartDate.getDate() - periodDays + 1)

  const { data: previousExpenses } = await supabase
    .from('expenses')
    .select('amount')
    .eq('user_id', user.id)
    .gte('expense_date', toISODateString(prevStartDate))
    .lte('expense_date', toISODateString(prevEndDate))

  // Get categories
  const { data: categories } = await supabase
    .from('categories')
    .select('*')
    .eq('user_id', user.id)

  const totalCurrent = expenses?.reduce((sum, e) => sum + Number(e.amount), 0) ?? 0
  const totalPrevious = previousExpenses?.reduce((sum, e) => sum + Number(e.amount), 0) ?? 0

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Expense Summary</h1>
        <p className="text-muted-foreground">
          Detailed analysis of your spending by date and category
        </p>
      </div>

      <DateRangeFilter 
        startDate={startDate} 
        endDate={endDate}
        preset={preset}
      />

      <PeriodComparison
        currentTotal={totalCurrent}
        previousTotal={totalPrevious}
        currentPeriod={{ start: startDate, end: endDate }}
        transactionCount={expenses?.length ?? 0}
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <CategorySummary 
          expenses={expenses ?? []} 
          categories={categories ?? []}
        />
        <PaymentMethodSummary expenses={expenses ?? []} />
      </div>

      <DailyBreakdown 
        expenses={expenses ?? []} 
        startDate={startDate}
        endDate={endDate}
      />
    </div>
  )
}
